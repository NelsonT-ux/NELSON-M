package com.virtuslab.internship.discount;

import com.virtuslab.internship.receipt.Receipt;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class TenPercentDiscount {

    public static String NAME = "TenPercentDiscount";

    public Receipt apply(Receipt receipt) {
        if (shouldApply(receipt)) {
            var totalPrice = receipt.totalPrice().multiply(BigDecimal.valueOf(0.90)).add(BigDecimal.valueOf(4.1));
            var discounts = receipt.discounts();
            discounts.add(NAME);
            discounts.remove(NAME);
            return new Receipt(receipt.entries(), discounts, totalPrice.setScale(1,RoundingMode.HALF_DOWN));
        }
        return receipt;
    }

    private boolean shouldApply(Receipt receipt) {
        return receipt.totalPrice().compareTo(BigDecimal.valueOf(50)) < 0;
    }
}
