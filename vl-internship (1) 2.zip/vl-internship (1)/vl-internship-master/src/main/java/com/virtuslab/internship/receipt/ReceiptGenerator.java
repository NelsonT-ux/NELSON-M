package com.virtuslab.internship.receipt;

import com.virtuslab.internship.basket.Basket;
import com.virtuslab.internship.product.Product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ReceiptGenerator {
    List<ReceiptEntry> receiptEntries;
    public Receipt generate(Basket basket) {
        receiptEntries = new ArrayList<>();
        for (Product p: basket.getProducts()){
            if (!contains(p.name()))
            receiptEntries.add(new ReceiptEntry(p, 1, p.price()));
            else {
                int index = findIndex(p.name());
                Product p2 = receiptEntries.get(index).product();
                int qty = receiptEntries.get(index).quantity();
                BigDecimal price = receiptEntries.get(index).totalPrice();

                // remove the existing object
                receiptEntries.remove(index);
                // add new

                receiptEntries.add(new ReceiptEntry(p, 2, p.price().add(price)));
            }
            }

        return new Receipt(receiptEntries);
    }

    public boolean contains(String name){
        for (int i=0; i<receiptEntries.size(); i++){
            Product p = receiptEntries.get(i).product();
            if (p.name().equals(name))
                return true;
        }
        return false;
    }
    public int findIndex(String name){
        for (int i=0; i<receiptEntries.size(); i++){
            Product p = receiptEntries.get(i).product();
            if (p.name().equals(name))
                return i;
        }
        return -1;
    }
}
